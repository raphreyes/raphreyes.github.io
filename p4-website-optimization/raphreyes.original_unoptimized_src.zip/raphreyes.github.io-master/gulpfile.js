var gulp = require('gulp');
var minify = require ('gulp-minify');
var cleanCSS = require('gulp-clean-css');

gulp.task('minify', function(){
	gulp.src('src/views/js/main.js')
		.pipe(minify())
		.pipe(gulp.dest('dist/views/js'))
});

gulp.task('minify-css', function() {
    return gulp.src('src/views/css/*.css')
        .pipe(cleanCSS({debug: true}, function(details) {
            console.log(details.name + ': ' + details.stats.originalSize);
            console.log(details.name + ': ' + details.stats.minifiedSize);
        }))
        .pipe(gulp.dest('dist/views/css'));
});

gulp.task('default', function() {
//a blank default task so nothing happens if someone only types 'grunt'
});
