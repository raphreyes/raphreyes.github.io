# Project 4 website optimization
<p>
The final project can be tested on Google PageSpeed Insights via these URLs<br>
http://raphreyes.github.io/dist/index.html<br>
http://raphreyes.github.io/dist/views/pizza.html<br>
</p>
<p>
The Udacity Project 4 submission repository is located at: https://github.com/raphreyes/raphreyes.github.io
</p>
The proceedures for optimizing index.html and /views/pizza.html are below.

##Setup GULP and folders
<ol>
<li>Install GULP globally if not already installed.<br>
	See https://github.com/gulpjs/gulp/blob/master/docs/getting-started.md<br></li>
<li>Install GIMP for your Windows or OSX machine.<br>
	See https://www.gimp.org/downloads/<br></li>

<li>Download ngrok from http://ngrok.com/download<br></li>
<li>Make sure you have Python 2.7 installed so you can run SimpleHTTPServer.<br>
	See https://www.python.org/downloads/release/python-2711/<br></li>
<li>Once GULP is installed, do the installs of the following gulp plugins to the project folder:<br>
	gulp --save-dev<br>
	gulp-minify --save-dev<br>
	gulp-clean-css --save-dev<br></li>
<li>Place all project source files in folder 'src'. Duplicate the src folder and rename it as 'dist'.<br></li>
<li>Final optimized project will be in folder 'dist'. We will overwrite files in dist with optimized versions.<br></li>
</ol>
<br>
##Optimizing index.html
<ol>
<li>Remove the link tags to style.css and print.css<br></li>
<li>Open style.css and print.css from 'src/css' and inline all of their css into a style tag within the head tag.<br></li>
<li>Load the google webfont stylsheet in your browser.<br>
	The Google webfont css in the link is here: http://fonts.googleapis.com/css?family=Open+Sans:400,700<br>
	Copy the css that appears in the browser and append it to the css in the style tag created in step 2.<br>
	All css is now inline. Delete the <link> tag to the google web-font.<br></li>
<li>Open pizzeria.jpg in gimp and reduce the image to a width of 100px. Be sure to keep aspect-ratio locked so it resizes down correctly. We use 100px width because is the specified width in the html code for the thumbnails to be displayed. Save this image as pizzeria-sm.jpg into the 'src/views/images' and another copy into 'dist/views/images' folder.<br></li>
<li>Change the html image src for pizzeria.jpg to pizzeria-sm.jpg so it calls the 100px wide thumbnail you saved in step 8. Hint: the image is the last one in the unordered list right above the 'a' tag for Cam's Pizzeria.<br></li>
<li>Select all of the html and copy. Go to www.willpeavy.com/minifier/ and paste the html code, then click the minify button.<br>
Copy the minified html and save it as /dist/index.html.<br></li>
<li>Test your index.html using the steps in the section called 'Testing on Google Pagespeed Insights'<br></li>
</ol>
##Optimize pizza.html and main.js
<ol>
<li>In 'src/views/pizza.html' set the viewport using meta name="viewport" content="width=device-width, initial-scale=1"<br></li>
<li>Minify the css in 'src/views/css/' and output the results to 'dist/views/css/'<br></li>
<li>Open 'src/views/images/pizzeria.jpg' in GIMP.<br></li>
	Since the image is never displayed at full screen width, reduce the width to 1024 while preserving the aspect ratio.
	Save pizzeria.jpg in 'dist/views/images/pizzeria.jpg' with a jpg quality setting of 7.<br></li>
<li>Remove the <link> to bootstrap-grid.css and style.css in pizzeria.html<br></li>
<li>Fix prioritization of content above the fold.<br>
	Open pizza.html<br>
	In the div with id="calltoAction" there are two divs that contain columns classes ('col-mm-4 and col-md-8').<br>
	Move the div with class 'col-md-4' so it is after 'col-md-8'.<br></li>
<li>Open 'src/views/js/main.js'<br>
<li>Find all document.querySelectorAll() statements and replace with document.getElementsByClassName or document.getElementById, as needed.</li>
<li>Create pizzasDiv declaraction outside of the For loop and use it in the loop for the appendChild (see line 450 in main.js).</li>
<ol>
	<li>Update the function 'updatePositions' with the following (can also see comments in code):</li>
	<ol>
		<li>Specifically, break up the original phase variable by creating 'var scroll = (document.body.scrollTop / 1250);'</li>
		<li>Declare 'document.getElementsByClassName('mover')' as a variable, as well as it's .length.</li>
		<li>Declare phase, outside of the loop.</li>
		<li>We must also make changes for converting .left and .basicLeft into transforms as they keep forcing layout. [ See specific main.js code changes/comments for function updatePositions and also this page by Google. https://developers.google.com/web/fundamentals/performance/rendering/stick-to-compositor-only-properties-and-manage-layer-count#use-transform-and-opacity-changes-for-animations ]
		<li>Add the following styles to the .mover class css {will-change: transform; transform: translateZ(0);}</li>
	</ol>

	<li>Update the function 'changeSliderLabel' by returning a value 25, 33, 50 and declare a var pizzaSize to get the return value. Don't forget to replace querySelectorAll with getElementById.</li>
	<li>Update the formula changePizzaSizes by assigning var allPizzas to document.querySelectorAll(".randomPizzaContainer") outside of the for loop.<br></li>
	<li>Update the changePizzaSizes For loop using the variable pizzaSize you created in function changeSliderLabel. Declare allPizzas outside the For loop. The only line you need in the for loop will be: allPizza[i].style.width = pizzaSize + "%"; - see the main.js @ changePizzaSizes function for these changes.<br></li>
	<li>Reduce the 200 pizza count in the For loop to 32 pizzas enough to fill the screen, OR Dynamic generation of pizza rows is possible, see code how this is implemented. See main.js @ line 529 addEventListener  </li>
	<li>Minify the js file with gulp and output the minified js into 'dist/views/js'.<br></li>
	<li>Make sure the script tag at the end of pizzeria.html calls 'dist/views/js/main-min.js'<br></li>
	</ol>
<li>Open 'dist/views/css/style.css and 'dist/views/css/bootstrap-grid.css' which were minified in step 2 for this section.<br></li>
<li>Copy and paste all the css from those minified stylesheets into a style tag in 'src/views/pizza.html'.<br></li>
	The style tag should be within the <head> tag of pizza.html<br>
	Save pizza.html which should now contain all the minified css inline.<br></li>
<li>Select all the code of pizzeria.html.<br>
	Go to www.willpeavy.com/minifier/ and paste the pizzeria html code, then click the minify button.<br>
	Copy the minified HTML and save it as 'pizza.html' into the 'dist/views/' folder.<br></li>
<li>Test pizza.html in Google Pagespeed Insights.<br></li>
</ol>

##Testing on Google Pagespeed Insights
To test your optimizations on Google Pagespeed Insights do the following:<br>
<ol>
<li>Navigate to your 'dist' folder in your command line.<br></li>
<li>Once you are in the folder 'dist', type python -m SimpleHTTPServer 8080<br></li>
<li>Start ngrok cli and type ngrok http 8080.<br></li>
<li>ngrok will give you a url. Enter that url into your browser to verify index.html loads.<br></li>
<li>After verifying index.html is loading, copy the address with ctrl-c (or option-c).<br></li>
<li>Open a tab to the following address: https://developers.google.com/speed/pagespeed/insights/<br></li>
<li>Paste the url into the form and click the Analyze button. You should receive a score.<br></li>
</ol>
